/*
 * module to include the modules
 */

config_require(ip-mib/ipv4InterfaceTable/ipv4InterfaceTable)
