#ifndef _AGENTX_MIBGROUP_H
#define _AGENTX_MIBGROUP_H

config_require(agentx/master)
config_require(agentx/subagent)
#endif                          /* _AGENTX_MIBGROUP_H */
