#ifndef DATA_SET_H
#define DATA_SET_H

#ifdef __cplusplus
extern "C" {
#endif

void            init_data_set(void);
void            shutdown_data_set(void);


#ifdef __cplusplus
}
#endif

#endif                          /* DATA_SET_H */
